#pragma once
#include <string>
#include <set>

struct نية {
    std::string الغاية;
    std::set<std::string> رايات;
};
